Empty Front Page
----------------

This is an ultra lightweight module that remove default content from 
the frontpage.

Installation
------------
Place empty_front_page in the modules directory for your site and enable it.
